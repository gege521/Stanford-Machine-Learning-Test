function centroids = kMeansInitCentroids(X, K)
%KMEANSINITCENTROIDS This function initializes K centroids that are to be 
%used in K-Means on the dataset X
%   centroids = KMEANSINITCENTROIDS(X, K) returns K initial centroids to be
%   used with the K-Means on the dataset X
%

% You should return this values correctly
centroids = zeros(K, size(X, 2));

% ====================== YOUR CODE HERE ======================
% Instructions: You should set centroids to randomly chosen examples from
%               the dataset X
%

nrows = size(X,1);
nrand = K; % Choose 1000 rows
assert(nrand<=nrows, 'You cannot choose more rows than exist in the matrix');
rand_rows = randperm(nrows, nrand);
centroids = X(rand_rows,:);  % Select the random rows from x







% =============================================================

end

